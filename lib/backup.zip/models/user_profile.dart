class UserProfileModel {
  // api fields = ['auth_user_id', 'username', 'email', 'first_name',
  // 'last_name']
  int authUserId;
  String username;
  String email;
  String firstName;
  String lastName;

  UserProfileModel({
    this.authUserId,
    this.username,
    this.email,
    this.firstName,
    this.lastName,
  });

  factory UserProfileModel.fromJSON(Map<String, dynamic> json) {
    return UserProfileModel(
      authUserId: json['auth_user_id'],
      username: json['username'],
      email: json['email'],
      firstName: json['first_name'],
      lastName: json['last_name'],
    );
  }
}
