library com.lfiorani.globals;

bool userLoggedIn = false;
int tokenValidity = 24;