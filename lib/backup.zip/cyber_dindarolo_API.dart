import 'package:cyberdindaroloapp/utils/rest_helper.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

import 'exceptions.dart';

import 'globals.dart' as globals;

class CyberDindaroloAPIv1 {
  static const String base_url = "http://10.0.2.2:8000/api/v1/";

  Map<String, String> urls = {
    'login': base_url + 'login/',
    'users': base_url + 'users/',
  };

  // Singleton
  CyberDindaroloAPIv1._(); // Private constructor
  static final CyberDindaroloAPIv1 _cyberDindaroloAPIv1 =
      CyberDindaroloAPIv1._();

  factory CyberDindaroloAPIv1() => _cyberDindaroloAPIv1;

  final RestAPIutil restAPIutil = RestAPIutil();
  final storage = new FlutterSecureStorage();

  // Login to CyberDindaroloAPI, returns authentication token
  Future<String> authenticate({String username, String password}) async {
    var authBody;
    var token;
    var formatter = new DateFormat('yyyy-MM-dd HH');
    //await storage.delete(key: 'token-gen-date').timeout(const Duration(seconds: 5));;
    // Obtain shared preferences
    final prefs = await SharedPreferences.getInstance();

    if (username != null && password != null) {
      // Authenticate with given uname and pwd
      authBody = {'username': username, 'password': password};

      // Using not secured storage to store username
      prefs.setString('username', username);

      // Store encrypted pwd
      await storage
          .write(key: 'password', value: password)
          .timeout(const Duration(seconds: 5));
    } else {
      // Authenticate using stored credentials
      final tokenGenDateTimeStr = prefs.getString('token-gen-date') ?? '';

      if (tokenGenDateTimeStr.isEmpty)
        throw LoginCredentialNotStored(
            error: 'Can\'t find token-gen-date on storage.');

      DateTime tokenGenDateTime = formatter.parse(tokenGenDateTimeStr);
      if (tokenGenDateTime.difference(DateTime.now()).inHours >=
          globals.tokenValidity) {
        // If token not valid, repeat login with stored credentials
        final onStorageUname = prefs.getString('username') ?? '';
        if (onStorageUname.isEmpty)
          throw LoginCredentialNotStored(
              error: 'Can\'t find username on storage.');

        final onStoragePwd = await storage
            .read(key: 'password')
            .timeout(const Duration(seconds: 5));
        authBody = {'username': onStorageUname, 'password': onStoragePwd};
      } else {
        // If token valid, return token from storage
        return 'Token ' + await storage
            .read(key: 'token')
            .timeout(const Duration(seconds: 5));
      }
    }

    // Login and get token
    var response = await restAPIutil.post(urls['login'], body: authBody);

    // Store date for token validity
    var now = new DateTime.now();
    String tokenGenDateTime = formatter.format(now);
    prefs.setString('token-gen-date', tokenGenDateTime);

    token = response['token'];

    await storage
        .write(key: 'token', value: 'Token ' + token)
        .timeout(const Duration(seconds: 5));

    return 'Token ' + token;
  }

  Future<Map<String, String>> getAuthHeader() async {
    var token = await authenticate();

    var headers = {'Authorization': token};
    return headers;
  }

  Future<dynamic> getUsers({int page: 1, String pattern}) async {
    Map<String, String> headers = await getAuthHeader();

    var response =
        await restAPIutil.get(urls['users'] + '?page=$page', headers: headers);

    return response;
  }
}
