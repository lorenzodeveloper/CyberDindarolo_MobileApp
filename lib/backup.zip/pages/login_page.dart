import 'package:flutter/material.dart';

import '../cyber_dindarolo_API.dart';
import '../exceptions.dart';
import '../globals.dart' as globals;

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        title: Text('Login'),
      ),
      body: LoginForm(),
    );
  }
}

// Define a custom Form widget.
class LoginForm extends StatefulWidget {
  @override
  LoginFormState createState() {
    return LoginFormState();
  }
}

// Define a corresponding State class.
// This class holds data related to the form.
class LoginFormState extends State<LoginForm> {
  // Create a global key that uniquely identifies the Form widget
  // and allows validation of the form.
  //
  // Note: This is a `GlobalKey<FormState>`,
  // not a GlobalKey<MyCustomFormState>.
  final _formKey = GlobalKey<FormState>();

  final unameController = TextEditingController();
  final pwdController = TextEditingController();

  final CyberDindaroloAPIv1 api = CyberDindaroloAPIv1();

  @override
  void dispose() {
    // Clean up the controller when the widget is disposed.
    unameController.dispose();
    pwdController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Build a Form widget using the _formKey created above.
    return Form(
        key: _formKey,
        child: Padding(
            padding: EdgeInsets.all(10),
            child: Column(children: <Widget>[
              // Username field
              TextFormField(
                // The validator receives the text that the user has entered.
                validator: (value) {
                  if (value.isEmpty) {
                    return 'Please enter some text';
                  }
                  if (!value.contains(new RegExp(r'^[-a-zA-Z0-9_@.]+$'))) {
                    return 'Invalid characters';
                  }
                  if (value.length < 3) return 'At least 3 chars';
                  return null;
                },
                decoration: InputDecoration(labelText: 'Enter your username'),
                controller: unameController,
              ),
              // Pwd field
              TextFormField(
                // The validator receives the text that the user has entered.
                validator: (value) {
                  if (value.isEmpty) {
                    return 'Please enter some text';
                  }
                  if (value.length < 8) return 'At least 8 chars';
                  return null;
                },
                decoration: InputDecoration(labelText: 'Enter your password'),
                obscureText: true,
                controller: pwdController,
              ),
              RaisedButton(
                onPressed: () async {
                  // Validate returns true if the form is valid, otherwise false.
                  if (_formKey.currentState.validate()) {
                    print(unameController.text);
                    print(pwdController.text);

                    try {
                      await api.authenticate(
                          username: unameController.text,
                          password: pwdController.text);
                      globals.userLoggedIn = true;
                      Navigator.of(context).pushReplacementNamed('/home');
                    } on HttpException catch (e) {
                      Scaffold.of(context)
                          .showSnackBar(SnackBar(content: Text('$e')));
                    }
                  }
                },
                child: Text('Login'),
              ),
            ])));
  }
}
