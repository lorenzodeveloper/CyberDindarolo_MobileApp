import 'package:cyberdindaroloapp/exceptions.dart';
import 'package:cyberdindaroloapp/utils/alerts.dart';
import 'package:flutter/material.dart';

import '../cyber_dindarolo_API.dart';


class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int nextPage = 1;

  bool isLoading = false;

  List users = new List();

  bool dataFetchComplete = false;

  final CyberDindaroloAPIv1 api = CyberDindaroloAPIv1();

  void _getMoreData() async {
    if (dataFetchComplete) {
      print("Already fetched all data, exiting.");
      return;
    }

    if (!isLoading) {
      setState(() {
        isLoading = true;
      });

      try {
        final response = await api.getUsers(page: nextPage);

        List tempList = new List();

        if (response['next'] == null) dataFetchComplete = true;

        nextPage += 1;
        for (int i = 0; i < response['results'].length; i++) {
          tempList.add(response['results'][i]);
        }

        setState(() {
          isLoading = false;
          users.addAll(tempList);
        });
      } on HttpException catch (ex) {
        // Exception caught, return to login page
        showAlertDialog(context, 'Error', '$ex\n'
            'You will be redirect to the login page.', '/');
      }

    }
  }

  @override
  void initState() {
    //_scrollController = new ScrollController();
    this._getMoreData();
    super.initState();
  }

  /*@override
  void dispose() {
    //_scrollController.dispose();
    super.dispose();
  }*/

  Widget _buildProgressIndicator() {
    return new Padding(
      padding: const EdgeInsets.all(8.0),
      child: new Center(
        child: new Opacity(
          opacity: isLoading ? 1.0 : 00,
          child: new CircularProgressIndicator(),
        ),
      ),
    );
  }

  Widget _buildList() {
    return ListView.builder(
      //+1 for progressbar
      itemCount: users.length + 1,
      itemBuilder: (BuildContext context, int index) {
        if (index == users.length) {
          return _buildProgressIndicator();
        } else {
          return new ListTile(
            title: Text((users[index]['username'])),
            onTap: () {
              print(users[index]);
            },
          );
        }
      },
      physics: const AlwaysScrollableScrollPhysics(),
    );
  }

  _onEndScroll(ScrollMetrics metrics) {
    setState(() {
      if (metrics.pixels >= metrics.maxScrollExtent && !metrics.outOfRange) {
        setState(() {
          _getMoreData();
          // print("reach the bottom -> Fetching data");
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Pagination"),
      ),
      body: Container(
          child: Column(children: [
            NotificationListener<ScrollNotification>(
              onNotification: (scrollNotification) {
                if (scrollNotification is ScrollEndNotification) {
                  _onEndScroll(scrollNotification.metrics);
                  return true;
                }
                return false;
              },
              child: Expanded(child: _buildList()),
            ),
            Center(
                child: Padding(
                  child: Text(dataFetchComplete ? "Alla data is shown" : "Scroll down to fetch more data"),
                  padding: new EdgeInsets.all(8),
                )

            ),

          ])
      ),
      resizeToAvoidBottomPadding: false,
    );
  }
}