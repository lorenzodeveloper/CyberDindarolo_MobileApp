import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';
import 'dart:core';

import '../exceptions.dart';



class RestAPIutil {
  // Singleton
  RestAPIutil._(); //private constructor
  static final RestAPIutil _restData = RestAPIutil._();

  factory RestAPIutil() => _restData;

  Future<dynamic> get(String url, {Map headers}) async {
    http.Response response;
    response = await http
        .get(url, headers: headers)
        .timeout(const Duration(seconds: 5));

    final String ret = response.body;
    final int statusCode = response.statusCode;

    if (statusCode < 200 || statusCode >= 400) {
      throw HttpException(httpCode: statusCode, error: response.body);
    }
    return jsonDecode(ret);
  }

  Future<dynamic> post(String url, {Map headers, Map body, encoding}) async {
    body.removeWhere((k, v) => (v == null));
    http.Response response;

    response = await http
        .post(url, body: body, headers: headers, encoding: encoding)
        .timeout(const Duration(seconds: 5));

    final String ret = response.body;
    final int statusCode = response.statusCode;

    if (statusCode < 200 || statusCode >= 400) {
      throw HttpException(
          httpCode: statusCode, error: response.body.toString());
    }
    return jsonDecode(ret);
  }
}
