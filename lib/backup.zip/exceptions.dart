class HttpException implements Exception {
  // Custom HttpException

  final int httpCode;
  final String error;

  HttpException({this.httpCode, this.error});

  @override
  String toString() => "Error while fetching data: $httpCode - $error";
}

class UnauthenticatedException implements Exception {
  UnauthenticatedException() : super();

  @override
  String toString() => "Exception: UnauthenticatedException";
}


class LoginCredentialNotStored implements Exception {

  final String error;

  LoginCredentialNotStored({this.error});

  @override
  String toString() => "LoginCredentialNotStored:: - $error";
}